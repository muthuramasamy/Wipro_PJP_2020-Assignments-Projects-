package com.wipro.sample;

public abstract class Shape {
	String msg;
	abstract void draw();
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
