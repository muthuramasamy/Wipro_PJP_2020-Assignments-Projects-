

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Bid")
public class Bid extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String itemid,iname,yname,email,amt;
		itemid=request.getParameter("itemid").toString();
		iname=request.getParameter("iname").toString();
		yname=request.getParameter("yname").toString();
		email=request.getParameter("email").toString();
		amt=request.getParameter("amt").toString();
		//state=request.getParameter("state").toString();
	//System.out.println(uname);
	//System.out.println(pas);
	//System.out.println(dob);
	//System.out.println(phn);
	//System.out.println(add);
	//System.out.println(state);
		String url="jdbc:mysql://localhost:3306/wipro";
		String name="root";
		String password="root";
		Statement st=null;
		
		try {
			
			
			
				Class.forName("com.mysql.jdbc.Driver");	
				Connection con=DriverManager.getConnection(url,name,password);
			    st=con.createStatement();
			    String sql="insert into bid values('"+itemid+"','"+iname+"','"+yname+"','"+email+"','"+amt+"')";
			st.execute(sql);
			
			//out.println("registered");
			}
	
		catch(Exception e)
		{
			e.printStackTrace();
		}
}}
