//document.getElementyiD("myform").onsubmit=function(){validateForm()};

function validateForm() {

    // document.forms["myForm"]["fname"].value;
    var itemid = document.forms["myForm"]["itemid"].value;
    var iname = document.forms["myForm"]["iname"].value;
    var yname = document.forms["myForm"]["yname"].value;
    var email = document.forms["myForm"]["email"].value;
    var amt = document.forms["myForm"]["amt"].value;
    var a = 0;
    // console.log(pwd);
    //console.log(usid);

    if (itemid == "") {
        document.getElementById('iid').innerHTML = " Enter valid Item Id "
        a = 1;
    }
    if (iname == "") {
        document.getElementById('iiname').innerHTML = " Enter valid Item Name "

        a = 1;

    }
    if (yname == "") {
        document.getElementById('yyname').innerHTML = " Enter your name"

        a = 1;

    }
    if (email == "") {
        document.getElementById('mail').innerHTML = " Enter valid mail id "
        a = 1;


    }
    if (amt == "") {
        document.getElementById('aamt').innerHTML = " Enter valid amount "

        a = 1;

    }
    
    var form = document.getElementById("myForm");
    form.submit();
 
    
    if (a == 0) {
    	document.write("<div style='text-align: center;background-color:yellow';height:1200px;width:1000px>")
    	   document.write(" <h2 style='text-align: center'> Bid Submitted </h2>")
    	   document.write("<p>Your bid is now active.If your bid is successful,you will be notified with 24 hours pf the close of binding.</p>")
    	   document.write("<table border=1 style='  margin-left: 600px'>")
    	    document.write("<tr><td>Item id:"+itemid+"</td></tr>")
    	    document.write("<tr><td>Item Name:"+iname+"</td></tr>")
    	    document.write("<tr><td>your name:"+yname+"</td></tr>")
    	    document.write("<tr><td>email:"+email+"</td></tr>")
    	    document.write("<tr><td>Amount:"+amt+"</td></tr>")
    	    document.write("</table>")
    	    document.write("</div>")
    	return true;
        
    } else {
        return false;
    }



    
    return true;
}