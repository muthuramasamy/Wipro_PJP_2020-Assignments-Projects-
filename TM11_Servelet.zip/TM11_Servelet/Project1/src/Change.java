

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Change")
public class Change extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String user_name,opas,pas,cpas;
		user_name=request.getParameter("uname").toString();
		opas=request.getParameter("opas").toString();
		pas=request.getParameter("pas").toString();
		cpas=request.getParameter("cpas").toString();
		
		System.out.println(pas);
		System.out.println(cpas);
		String url="jdbc:mysql://localhost:3306/wipro";
		String name="root";
		String password="root";
		
	    String sql="select pass from login where uname=?";
	   
	    
	try {
		String s = null;
		
		 Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection(url,name,password);
		    PreparedStatement st=con.prepareStatement(sql);
		    st.setString(1,user_name);
		    ResultSet rs = st.executeQuery();
		    while (rs.next())
		      {
		     
		      s = rs.getString("pass");
		   
		      
		    System.out.println(s);
		      }
		    if(s.equals(opas))
		    {
		    	System.out.println("innnnn");
		    	if(pas.equals(pas)&&cpas.equals(cpas))
				
				{
		    		System.out.println("innnnn loop");
		    		String sql1="update login set  pass= ? where uname=?";
				    PreparedStatement st1=con.prepareStatement(sql1);
 
				  
				    st1.setString(1,pas);
				    st1.setString(2,user_name );
				   // st.setString(2,user_name);
				st1.execute();
				System.out.println("in");
				out.println("updated");
				}
		    	
				else {
			    System.out.println("wrong");
				out.println("Password and Conform Password are different");
				}
		    }
		    else
		    {
		    	out.println("Entered old password is wrong");
		    }
		    st.close();
	   
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
