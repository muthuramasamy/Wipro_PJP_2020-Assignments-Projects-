

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

@WebServlet("/Newuser")
public class Newuser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String uname,pas,cpas;
		uname=request.getParameter("uname").toString();
		pas=request.getParameter("pas").toString();
		cpas=request.getParameter("cpas").toString();
	
		String url="jdbc:mysql://localhost:3306/wipro";
		String name="root";
		String password="root";
		Statement st=null;
		
		try {
			
			
			if(pas.equals(pas)&&cpas.equals(cpas))
		
			{
				Class.forName("com.mysql.jdbc.Driver");	
				Connection con=DriverManager.getConnection(url,name,password);
			    st=con.createStatement();
			    String sql="insert into login values('"+uname+"','"+pas+"')";
			st.execute(sql);
			
			out.println("registered");
			}
			else {
		  
			out.println("Password and Conform Password are different");
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
