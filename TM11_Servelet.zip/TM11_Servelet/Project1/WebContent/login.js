
//document.getElementyiD("myform").onsubmit=function(){validateForm()};

function validateForm() {
   var usid = document.forms["myForm"]["uid"].value;
    var pwd = document.forms["myForm"]["pass"].value;
   var t=0;
  
  if (usid == "") {
       document.getElementById('uuid').innerHTML = " Enter valid User Name "

t=1;
  
   }
    if (pwd == "") {
   document.getElementById('ppwd').innerHTML = " Enter valid Correct Password "

        	t=1;

    }   
    var form = document.getElementById("myForm");
    form.submit();
    if(t=1)
    	{
    	return false;
    	}
    else
    	{
    	return true;
    	}


    //return true;
}