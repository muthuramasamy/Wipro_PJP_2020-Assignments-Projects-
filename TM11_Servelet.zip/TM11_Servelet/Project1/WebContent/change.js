

function validateForm() {
   var usid = document.forms["myForm"]["uname"].value;
    var pas = document.forms["myForm"]["pas"].value;
    var opas = document.forms["myForm"]["opas"].value;
    var cpas = document.forms["myForm"]["cpas"].value;
    
   var t=0;
  
  if (usid == "") {
       document.getElementById('user').innerHTML = " Enter valid User Name "

t=1;
  
   }
    if (pas == "") {
   document.getElementById('nnpas').innerHTML = " Enter valid Correct Password "

        	t=1;

    }   
    if (opas == "") {
    	   document.getElementById('oopas').innerHTML = " Enter valid Correct Password "

    	        	t=1;

    	    }   
    if (cpas == "") {
    	   document.getElementById('ccpas').innerHTML = " Enter valid Correct Password "

    	        	t=1;

    	    }   
    var form = document.getElementById("myForm");
    form.submit();
    if(t=1)
    	{
    	return false;
    	}
    else
    	{
    	
    	return true;
    	
    	}


    //return true;
}